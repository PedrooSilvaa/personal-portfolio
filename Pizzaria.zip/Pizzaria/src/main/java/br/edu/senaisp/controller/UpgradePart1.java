package br.edu.senaisp.controller;

import java.io.IOException;
import java.io.PrintWriter;

import br.edu.senaisp.dao.SaborDao;
import br.edu.senaisp.model.Sabor;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet(urlPatterns = "updatepart1")
public class UpgradePart1 extends HttpServlet {

	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
System.out.println("");
		
		int numero = Integer.parseInt(req.getParameter("numero"));
		
		StringBuilder html = new StringBuilder();
		html.append("");
		html.append("<!DOCTYPE html>");
		html.append("<html>");
		html.append("<head>");
		html.append("<meta charset='ISO-8859-1'>");
		html.append("<title>Pagina Principal</title>");
		html.append("</head>");
		html.append("<body>");
		
		SaborDao dao = new SaborDao();
		for (Sabor sabor : dao.lista()) {
			
		html.append("<form action='/Pizzaria/update'>");
		html.append("<label for='nomeVar'>Nome da variavel</label>");
		html.append("<input type='text' name='nomeVar'> ");
		html.append("<label for='conteudo'>Oque mudaras?</label>");
		html.append("<input type='text' name='conteudo'>");
		html.append("<label for='numero'> id</label>");
		html.append("<input type='number' name='numero' value=").append(numero).append(">");
		html.append("<button type='submit'>mudar</button></form>");
		}
			
		html.append("</body>");
		html.append("</html>");
		
		PrintWriter pw = resp.getWriter();
		pw.print(html.toString());
		

	}
	
}
